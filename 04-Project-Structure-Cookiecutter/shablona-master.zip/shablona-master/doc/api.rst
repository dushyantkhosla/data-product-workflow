API
===


Classes
-------

.. currentmodule:: shablona

.. autosummary::
   :template: class.rst
   :toctree: gen_api

   Model


Functions
---------

.. autosummary::
   :template: function.rst
   :toctree: gen_api

   transform_data
   cumgauss
   opt_err_func
