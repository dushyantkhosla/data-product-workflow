
This is a theory section
========================

I might want to describe some equations: 

.. math::

    \int_0^\infty e^{-x^2} dx=\frac{\sqrt{\pi}}{2}


And refer to a paper [author2015]_.


.. [author2015] first a., second a., cheese b. (2015). The title of their 
                paper. Journal of papers, *15*: 1023-1049.

