Shablona Gallery
================

This is the main gallery page for sphinx-gallery. It contains preview
images of the scripts contained in all of the sub-folders of this folder.
It also breaks these images into subsections based on folder. Click one of
the images below to be taken its corresponding example.