Model fitting examples
----------------------

These are a collection of examples demonstrating the model fitting
functionality of shablona, as well as how examples can be compiled into
a gallery with `sphinx-gallery`.
