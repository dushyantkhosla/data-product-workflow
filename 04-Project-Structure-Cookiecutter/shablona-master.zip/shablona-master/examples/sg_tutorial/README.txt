Sphinx-Gallery tutorial
-----------------------

This folder contains a tutorial to demonstrate some functionality of
sphinx-gallery. It is a quick tour of features but doesn't cover
everything that you can do with rST.